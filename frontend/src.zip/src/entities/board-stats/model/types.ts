export type BoardStatsSummary = {
    totalTasks: number
    todoCount: number
    inProgressCount: number
    doneCount: number
    wipCount: number
    doneLast7Days: number
    doneLast30Days: number
    avgCycleTimeHours: number | null
    medianCycleTimeHours: number | null
    avgLeadTimeHours: number | null
}

export type ThroughputPoint = {
    date: string
    count: number
}

export type CfdPoint = {
    date: string
    todo: number
    inProgress: number
    done: number
}

export type CycleTimePoint = {
    taskId: string
    taskTitle: string
    completedAt: string
    cycleTimeHours: number
}

export type BoardStats = {
    summary: BoardStatsSummary
    throughputByDay: ThroughputPoint[]
    cfdByDay: CfdPoint[]
    cycleTimePoints: CycleTimePoint[]
}
