export interface User {
    id: string
    username: string
    email: string
    createdAt: string
}
