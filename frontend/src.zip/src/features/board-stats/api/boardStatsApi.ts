import { api } from '@/shared/api'
import type { BoardStats } from '@/entities/board-stats'

export const getBoardStats = async (boardId: string, days = 30) => {
    const response = await api.get<BoardStats>(`/board-stats/${boardId}`, {
        params: { days },
    })

    return response.data
}
