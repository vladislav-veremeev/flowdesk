import { useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, LogOut, MailPlus, Send } from 'lucide-react'
import {
    closestCorners,
    type CollisionDetection,
    DndContext,
    DragOverlay,
    pointerWithin,
} from '@dnd-kit/core'
import {
    horizontalListSortingStrategy,
    SortableContext,
} from '@dnd-kit/sortable'
import { toast } from 'sonner'

import { userStore } from '@/entities/user'
import { ColumnCard } from '@/entities/column'
import { TaskCard } from '@/entities/task'
import { AddColumnPopover } from '@/features/columns'
import { createBoardInvitation } from '@/features/board-invitations'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card } from '@/components/ui/card.tsx'
import {
    Dialog,
    DialogClose,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
} from '@/components/ui/dialog'
import { Input } from '@/components/ui/input'
import {
    Item,
    ItemActions,
    ItemContent,
    ItemDescription,
    ItemTitle,
} from '@/components/ui/item.tsx'
import { useBoardPage } from '../model/useBoardPage'
import { parseSortableId, useBoardDnd } from '../model/useBoardDnd'
import { Field, FieldError, FieldLabel } from '@/components/ui/field.tsx'
import { Controller, useForm } from 'react-hook-form'
import z from 'zod'
import { zodResolver } from '@hookform/resolvers/zod'
import { leaveBoard } from '@/features/board-members'
import {
    AlertDialog,
    AlertDialogAction,
    AlertDialogCancel,
    AlertDialogContent,
    AlertDialogDescription,
    AlertDialogFooter,
    AlertDialogHeader,
    AlertDialogTitle,
    AlertDialogTrigger,
} from '@/components/ui/alert-dialog.tsx'
import { BoardPageHeader } from '@/pages/board'

const getColumnSortableId = (columnId: string) => `column-${columnId}`

const inviteSchema = z.object({
    email: z
        .string()
        .trim()
        .min(1, 'Введите email')
        .email('Некорректный email'),
})

type InviteFormValues = z.infer<typeof inviteSchema>

const inviteDefaultValues: InviteFormValues = {
    email: '',
}

export const BoardPage = () => {
    const { id } = useParams<{ id: string }>()
    const user = userStore((state) => state.user)
    const [inviteDialogOpen, setInviteDialogOpen] = useState(false)
    const navigate = useNavigate()

    const inviteForm = useForm<InviteFormValues>({
        resolver: zodResolver(inviteSchema),
        defaultValues: inviteDefaultValues,
    })

    const resetInviteForm = () => {
        inviteForm.reset(inviteDefaultValues)
    }

    const collisionDetection: CollisionDetection = (args) => {
        const activeParsed = parseSortableId(args.active.id)

        if (!activeParsed) {
            return closestCorners(args)
        }

        if (activeParsed.type === 'column') {
            const columnContainers = args.droppableContainers.filter(
                (container) => {
                    const parsed = parseSortableId(container.id)
                    return parsed?.type === 'column'
                }
            )

            return closestCorners({
                ...args,
                droppableContainers: columnContainers,
            })
        }

        const pointerCollisions = pointerWithin(args)

        if (pointerCollisions.length > 0) {
            return pointerCollisions
        }

        return closestCorners(args)
    }

    const {
        board,
        members,
        columns,
        tasks,
        setColumns,
        setTasks,
        addColumnOpen,
        setAddColumnOpen,
        addTaskOpenColumnId,
        columnForm,
        taskForm,
        resetColumnForm,
        resetTaskForm,
        handleOpenAddTask,
        handleAddColumn,
        handleEditColumn,
        handleDeleteColumn,
        handleAddTask,
        handleEditTask,
        handleDeleteTask,
        isLoading,
        loadError,
    } = useBoardPage(id)

    const {
        sensors,
        sortedColumns,
        tasksByColumn,
        activeColumn,
        activeTask,
        handleDragStart,
        handleDragOver,
        handleDragCancel,
        handleDragEnd,
    } = useBoardDnd({
        boardId: id,
        columns,
        tasks,
        setColumns,
        setTasks,
    })

    const isOwner = !!board && !!user && board.ownerId === user.id

    const handleInviteMember = async (data: InviteFormValues) => {
        if (!id) return

        try {
            await createBoardInvitation({
                boardId: id,
                inviteeEmail: data.email,
            })

            toast.success('Приглашение успешно отправлено')
            resetInviteForm()
            setInviteDialogOpen(false)
        } catch (error: any) {
            toast.error(
                error.response?.data?.message ||
                    'Не удалось отправить приглашение'
            )
        }
    }

    if (isLoading) {
        return (
            <div className="flex flex-col px-6 py-4">
                <Item className="p-0">
                    <ItemContent>
                        <ItemTitle className="text-xl">
                            Загрузка доски...
                        </ItemTitle>
                        <ItemDescription>
                            Подождите, данные загружаются.
                        </ItemDescription>
                    </ItemContent>
                </Item>
            </div>
        )
    }

    if (!id || !board) {
        return (
            <div className="flex flex-col px-6 py-4">
                <Item className="p-0">
                    <ItemContent>
                        <ItemTitle className="text-xl">
                            Доска не найдена
                        </ItemTitle>

                        <ItemDescription>
                            {loadError ||
                                'Возможно, доска была удалена или у вас нет к ней доступа.'}
                        </ItemDescription>
                    </ItemContent>

                    <ItemActions>
                        <Button asChild variant="outline">
                            <Link to="/">
                                <ArrowLeft />
                                Назад
                            </Link>
                        </Button>
                    </ItemActions>
                </Item>
            </div>
        )
    }

    return (
        <div className="flex flex-col px-6 py-4 gap-4 h-[calc(100vh-69px)]">
            <BoardPageHeader
                board={board}
                members={members}
                isOwner={isOwner}
                inviteDialogOpen={inviteDialogOpen}
                setInviteDialogOpen={setInviteDialogOpen}
                inviteForm={inviteForm}
                onInviteMember={handleInviteMember}
                onResetInviteForm={resetInviteForm}
            />

            <DndContext
                collisionDetection={collisionDetection}
                sensors={sensors}
                onDragStart={handleDragStart}
                onDragOver={handleDragOver}
                onDragCancel={handleDragCancel}
                onDragEnd={handleDragEnd}
            >
                <SortableContext
                    items={sortedColumns.map((column) =>
                        getColumnSortableId(column.id)
                    )}
                    strategy={horizontalListSortingStrategy}
                >
                    <div className="flex overflow-x-auto h-full gap-6">
                        {tasksByColumn.map((column) => (
                            <ColumnCard
                                canManageColumn={isOwner}
                                key={column.id}
                                column={column}
                                addTaskOpenColumnId={addTaskOpenColumnId}
                                taskForm={taskForm}
                                onOpenAddTask={handleOpenAddTask}
                                onResetTaskForm={resetTaskForm}
                                onAddTask={handleAddTask}
                                onEditTask={handleEditTask}
                                onDeleteTask={handleDeleteTask}
                                onEditColumn={handleEditColumn}
                                onDeleteColumn={handleDeleteColumn}
                            />
                        ))}

                        {isOwner && (
                            <Card className="p-0 min-w-80 h-fit">
                                <AddColumnPopover
                                    open={addColumnOpen}
                                    onOpenChange={setAddColumnOpen}
                                    form={columnForm}
                                    onSubmit={handleAddColumn}
                                    onReset={resetColumnForm}
                                />
                            </Card>
                        )}
                    </div>
                </SortableContext>

                <DragOverlay>
                    {activeColumn ? (
                        <ColumnCard
                            column={activeColumn}
                            addTaskOpenColumnId={null}
                            taskForm={taskForm}
                            onOpenAddTask={handleOpenAddTask}
                            onResetTaskForm={resetTaskForm}
                            onAddTask={handleAddTask}
                            onEditTask={handleEditTask}
                            onDeleteTask={handleDeleteTask}
                            onEditColumn={handleEditColumn}
                            onDeleteColumn={handleDeleteColumn}
                            isOverlay
                        />
                    ) : activeTask ? (
                        <TaskCard
                            task={activeTask}
                            onEdit={handleEditTask}
                            onDelete={handleDeleteTask}
                            isOverlay
                        />
                    ) : null}
                </DragOverlay>
            </DndContext>
        </div>
    )
}
