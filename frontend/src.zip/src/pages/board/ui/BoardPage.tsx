import { Link, useParams } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { closestCorners, DndContext, DragOverlay } from '@dnd-kit/core'
import {
    horizontalListSortingStrategy,
    SortableContext,
} from '@dnd-kit/sortable'

import { ColumnCard } from '@/entities/column'
import { TaskCard } from '@/entities/task'
import { AddColumnPopover } from '@/features/columns'
import { Button } from '@/components/ui/button'
import {
    Item,
    ItemActions,
    ItemContent,
    ItemDescription,
    ItemTitle,
} from '@/components/ui/item.tsx'
import { Card } from '@/components/ui/card.tsx'
import { useBoardPage } from '../model/useBoardPage'
import { useBoardDnd } from '../model/useBoardDnd'

const getColumnSortableId = (columnId: string) => `column-${columnId}`

export const BoardPage = () => {
    const { id } = useParams<{ id: string }>()

    const {
        board,
        columns,
        tasks,
        setColumns,
        setTasks,
        addColumnOpen,
        setAddColumnOpen,
        addTaskOpenColumnId,
        columnForm,
        taskForm,
        resetColumnForm,
        resetTaskForm,
        handleOpenAddTask,
        handleAddColumn,
        handleEditColumn,
        handleDeleteColumn,
        handleAddTask,
        handleEditTask,
        handleDeleteTask,
    } = useBoardPage(id)

    const {
        sensors,
        sortedColumns,
        tasksByColumn,
        activeColumn,
        activeTask,
        handleDragStart,
        handleDragOver,
        handleDragCancel,
        handleDragEnd,
    } = useBoardDnd({
        boardId: id,
        columns,
        tasks,
        setColumns,
        setTasks,
    })

    if (!id || !board) {
        return (
            <div className="flex flex-col px-6 py-4">
                <Item className="p-0">
                    <ItemContent>
                        <ItemTitle className="text-xl">
                            Доска не найдена
                        </ItemTitle>

                        <ItemDescription>
                            Возможно, доска была удалена или у вас нет к ней
                            доступа.
                        </ItemDescription>
                    </ItemContent>

                    <ItemActions>
                        <Button asChild variant="outline">
                            <Link to="/">
                                <ArrowLeft />
                                Назад
                            </Link>
                        </Button>
                    </ItemActions>
                </Item>
            </div>
        )
    }

    return (
        <div className="flex flex-col px-6 py-4 gap-4 h-[calc(100vh-69px)]">
            <Item className="p-0">
                <ItemContent className="flex-row gap-2 items-center">
                    <ItemTitle className="text-xl">{board.title}</ItemTitle>
                    {board.description && (
                        <ItemDescription>{board.description}</ItemDescription>
                    )}
                </ItemContent>

                <ItemActions>
                    <Button asChild variant="outline">
                        <Link to="/">
                            <ArrowLeft />
                            Назад
                        </Link>
                    </Button>
                </ItemActions>
            </Item>

            <DndContext
                sensors={sensors}
                collisionDetection={closestCorners}
                onDragStart={handleDragStart}
                onDragOver={handleDragOver}
                onDragCancel={handleDragCancel}
                onDragEnd={handleDragEnd}
            >
                <SortableContext
                    items={sortedColumns.map((column) =>
                        getColumnSortableId(column.id)
                    )}
                    strategy={horizontalListSortingStrategy}
                >
                    <div className="flex overflow-x-auto h-full gap-6">
                        {tasksByColumn.map((column) => (
                            <ColumnCard
                                key={column.id}
                                column={column}
                                addTaskOpenColumnId={addTaskOpenColumnId}
                                taskForm={taskForm}
                                onOpenAddTask={handleOpenAddTask}
                                onResetTaskForm={resetTaskForm}
                                onAddTask={handleAddTask}
                                onEditTask={handleEditTask}
                                onDeleteTask={handleDeleteTask}
                                onEditColumn={handleEditColumn}
                                onDeleteColumn={handleDeleteColumn}
                            />
                        ))}

                        <Card className="p-0 min-w-80 h-fit">
                            <AddColumnPopover
                                open={addColumnOpen}
                                onOpenChange={setAddColumnOpen}
                                form={columnForm}
                                onSubmit={handleAddColumn}
                                onReset={resetColumnForm}
                            />
                        </Card>
                    </div>
                </SortableContext>

                <DragOverlay>
                    {activeColumn ? (
                        <ColumnCard
                            column={activeColumn}
                            addTaskOpenColumnId={null}
                            taskForm={taskForm}
                            onOpenAddTask={handleOpenAddTask}
                            onResetTaskForm={resetTaskForm}
                            onAddTask={handleAddTask}
                            onEditTask={handleEditTask}
                            onDeleteTask={handleDeleteTask}
                            onEditColumn={handleEditColumn}
                            onDeleteColumn={handleDeleteColumn}
                            isOverlay
                        />
                    ) : activeTask ? (
                        <TaskCard
                            task={activeTask}
                            onEdit={handleEditTask}
                            onDelete={handleDeleteTask}
                            isOverlay
                        />
                    ) : null}
                </DragOverlay>
            </DndContext>
        </div>
    )
}
