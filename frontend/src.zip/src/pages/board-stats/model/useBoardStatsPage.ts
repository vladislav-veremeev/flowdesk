import { useEffect, useState } from 'react'
import type { Board } from '@/entities/board'
import type { BoardStats } from '@/entities/board-stats'
import { getBoardById } from '@/features/boards'
import { getBoardStats } from '@/features/board-stats'
import { getApiErrorMessage } from '@/shared/lib'

export const useBoardStatsPage = (boardId?: string) => {
    const [board, setBoard] = useState<Board | null>(null)
    const [stats, setStats] = useState<BoardStats | null>(null)
    const [days, setDays] = useState(30)
    const [isLoading, setIsLoading] = useState(true)
    const [loadError, setLoadError] = useState<string | null>(null)

    useEffect(() => {
        const load = async () => {
            if (!boardId) {
                setIsLoading(false)
                setLoadError('Доска не найдена')
                return
            }

            try {
                setIsLoading(true)
                setLoadError(null)

                const [boardData, statsData] = await Promise.all([
                    getBoardById(boardId),
                    getBoardStats(boardId, days),
                ])

                setBoard(boardData)
                setStats(statsData)
            } catch (error) {
                setBoard(null)
                setStats(null)
                setLoadError(
                    getApiErrorMessage(
                        error,
                        'Не удалось загрузить статистику доски'
                    )
                )
            } finally {
                setIsLoading(false)
            }
        }

        load()
    }, [boardId, days])

    return {
        board,
        stats,
        days,
        setDays,
        isLoading,
        loadError,
    }
}
