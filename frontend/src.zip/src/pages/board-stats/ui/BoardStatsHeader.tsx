import { Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select'
import {
    Item,
    ItemActions,
    ItemContent,
    ItemDescription,
    ItemTitle,
} from '@/components/ui/item'

type BoardStatsHeaderProps = {
    boardTitle: string
    days: number
    onDaysChange: (value: number) => void
    boardId: string
}

export const BoardStatsHeader = ({
    boardTitle,
    days,
    onDaysChange,
    boardId,
}: BoardStatsHeaderProps) => {
    return (
        <Item className="p-0">
            <ItemContent>
                <ItemTitle className="text-xl">
                    Статистика доски: {boardTitle}
                </ItemTitle>
                <ItemDescription>
                    Статистика доски на выбранный период времени.
                </ItemDescription>
            </ItemContent>

            <ItemActions>
                <Select
                    value={String(days)}
                    onValueChange={(value) => onDaysChange(Number(value))}
                >
                    <SelectTrigger className="bg-background">
                        <SelectValue placeholder="Период" />
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="7">7 дней</SelectItem>
                        <SelectItem value="30">30 дней</SelectItem>
                        <SelectItem value="90">90 дней</SelectItem>
                    </SelectContent>
                </Select>

                <Button asChild variant="outline">
                    <Link to={`/boards/${boardId}`}>
                        <ArrowLeft />
                        Назад
                    </Link>
                </Button>
            </ItemActions>
        </Item>
    )
}
