import type { BoardStats } from '@/entities/board-stats'
import {
    Area,
    AreaChart,
    Bar,
    BarChart,
    CartesianGrid,
    Line,
    LineChart,
    XAxis,
    YAxis,
} from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
    type ChartConfig,
    ChartContainer,
    ChartLegend,
    ChartLegendContent,
    ChartTooltip,
    ChartTooltipContent,
} from '@/components/ui/chart'

type BoardStatsChartsProps = {
    stats: BoardStats
}

const throughputChartConfig = {
    count: {
        label: 'Завершено задач',
        color: 'var(--chart-1)',
    },
} satisfies ChartConfig

const cycleTimeChartConfig = {
    cycleTimeHours: {
        label: 'Cycle time (часы)',
        color: 'var(--chart-2)',
    },
} satisfies ChartConfig

const cfdChartConfig = {
    todo: {
        label: 'К работе',
        color: 'var(--chart-1)',
    },
    inProgress: {
        label: 'В работе',
        color: 'var(--chart-2)',
    },
    done: {
        label: 'Выполнено',
        color: 'var(--chart-3)',
    },
} satisfies ChartConfig

const formatShortDate = (value: string) => {
    const date = new Date(value)

    return date.toLocaleDateString('ru-RU', {
        day: '2-digit',
        month: '2-digit',
    })
}

export const BoardStatsCharts = ({ stats }: BoardStatsChartsProps) => {
    return (
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <Card>
                <CardHeader>
                    <CardTitle>Throughput по дням</CardTitle>
                </CardHeader>
                <CardContent>
                    <ChartContainer config={throughputChartConfig}>
                        <BarChart
                            accessibilityLayer
                            data={stats.throughputByDay}
                        >
                            <CartesianGrid vertical={false} />
                            <XAxis
                                dataKey="date"
                                tickLine={false}
                                axisLine={false}
                                tickMargin={8}
                                tickFormatter={formatShortDate}
                            />
                            <YAxis allowDecimals={false} />
                            <ChartTooltip
                                content={
                                    <ChartTooltipContent
                                        labelFormatter={(value) =>
                                            formatShortDate(String(value))
                                        }
                                    />
                                }
                            />
                            <Bar
                                dataKey="count"
                                radius={8}
                                fill="var(--color-count)"
                            />
                        </BarChart>
                    </ChartContainer>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Cycle time по завершённым задачам</CardTitle>
                </CardHeader>
                <CardContent>
                    <ChartContainer config={cycleTimeChartConfig}>
                        <LineChart
                            accessibilityLayer
                            data={stats.cycleTimePoints}
                        >
                            <CartesianGrid vertical={false} />
                            <XAxis
                                dataKey="completedAt"
                                tickLine={false}
                                axisLine={false}
                                tickMargin={8}
                                tickFormatter={formatShortDate}
                            />
                            <YAxis
                                dataKey="cycleTimeHours"
                                tickLine={false}
                                axisLine={false}
                            />
                            <ChartTooltip
                                content={
                                    <ChartTooltipContent
                                        labelFormatter={(value, payload) => {
                                            const item = payload?.[0]?.payload

                                            if (!item) {
                                                return String(value)
                                            }

                                            return `${item.taskTitle} • ${formatShortDate(
                                                item.completedAt
                                            )}`
                                        }}
                                    />
                                }
                            />
                            <Line
                                type="monotone"
                                dataKey="cycleTimeHours"
                                stroke="var(--color-cycleTimeHours)"
                                strokeWidth={2}
                                dot={{ r: 4 }}
                                activeDot={{ r: 6 }}
                            />
                        </LineChart>
                    </ChartContainer>
                </CardContent>
            </Card>

            <Card>
                <CardHeader>
                    <CardTitle>Cumulative Flow Diagram</CardTitle>
                </CardHeader>
                <CardContent>
                    <ChartContainer config={cfdChartConfig}>
                        <AreaChart accessibilityLayer data={stats.cfdByDay}>
                            <CartesianGrid vertical={false} />
                            <XAxis
                                dataKey="date"
                                tickLine={false}
                                axisLine={false}
                                tickMargin={8}
                                tickFormatter={formatShortDate}
                            />
                            <YAxis allowDecimals={false} />
                            <ChartTooltip
                                content={
                                    <ChartTooltipContent
                                        labelFormatter={(value) =>
                                            formatShortDate(String(value))
                                        }
                                    />
                                }
                            />
                            <ChartLegend content={<ChartLegendContent />} />
                            <Area
                                type="monotone"
                                dataKey="todo"
                                stackId="a"
                                stroke="var(--color-todo)"
                                fill="var(--color-todo)"
                                fillOpacity={0.4}
                            />
                            <Area
                                type="monotone"
                                dataKey="inProgress"
                                stackId="a"
                                stroke="var(--color-inProgress)"
                                fill="var(--color-inProgress)"
                                fillOpacity={0.4}
                            />
                            <Area
                                type="monotone"
                                dataKey="done"
                                stackId="a"
                                stroke="var(--color-done)"
                                fill="var(--color-done)"
                                fillOpacity={0.4}
                            />
                        </AreaChart>
                    </ChartContainer>
                </CardContent>
            </Card>
        </div>
    )
}
